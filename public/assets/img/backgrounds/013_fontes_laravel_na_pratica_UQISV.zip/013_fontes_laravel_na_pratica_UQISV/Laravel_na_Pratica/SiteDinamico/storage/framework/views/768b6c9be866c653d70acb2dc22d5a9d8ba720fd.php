<div class="row section">
	<h3 align="center">Imóveis</h3>
	<div class="divider"></div>
	<br>
	<?php echo $__env->make('layouts._site._filtros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="row section">
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>
	<div class="col s12 m3">
		<div class="card">
			<div class="card-image">
				<a href="#"><img src="<?php echo e(asset('img/modelo_img_home.jpg')); ?>" alt="Imagem"></a>
			</div>
			<div class="card-content">
				<p><b class="deep-orange-text darken-1">VENDE</b></p>
				<p><b>Título do Imóvel</b></p>
				<p>Descrição do imóvel</p>
				<p>R$200.000,00</p>
			</div>
			<div class="card-action">
				<a href="#">Ver mais..</a>
			</div>
		</div>
	</div>

</div>